To jest część poświęcona analize lotów pod względem opóźnień

Wsystkie wykresy znajdują się w folderze o nazwie "wykresy" i są posegregowane w podkatalogach


Jakie wykresy były zrobione w jakim pliku:

"Opoznienie_Ogolnie_2007" <- catch_up_delay.R - w drugiej części kodu
"nadganianie_przez_modele" <- top_used_models_delays.R
"nadganianie_przez_producenta" <- top_used_models_delays.R
"nadganianie_rok_produkcji"<- catch_up_delay.R - w pierwszej części kodu
"opoznienia_modeli" <- most_delayed_arrivals.R
"opoznienia_pora_roku" <- delays_depending_on_month.R