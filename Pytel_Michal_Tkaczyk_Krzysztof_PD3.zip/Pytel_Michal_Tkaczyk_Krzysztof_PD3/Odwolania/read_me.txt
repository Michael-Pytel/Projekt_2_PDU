Kod generujący wykresy jest w plikach:
top_routes_us_map.R - mapa z najpopularniejszymi trasami lotu
cancellation_stats.R - 2 wykresy odnoszące się do ilości anulowanych lotów dla każdego roku + wykres z ilością wszystkich zarejestrowanych lotów w danym roku
searching_for_source_of_cancellation.R- wykres z 8 mapami odwołanych lotów dla wybranych lat + wykres z ilością anulowanych lotów dla każdego kodu odwołania

W pozostałych plikach *.R jest kod "testowy" (historia tworzenia i testowania niektórych funkcji; sprawdzanie różnych metod pracy z danymi; pobieranie, wczytywanie i zapisywanie danych). 

W folderze wykresy są zapisane wykresy.

W folderze zapisane są zapisane ramki danych (wygenerowane przez nas i m.in. wczytywane w pliku searchig_for_source_of_cancellation.R).